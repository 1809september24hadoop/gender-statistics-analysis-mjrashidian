package com.revature;
/*
*This Driver calls a MapReduce to find the countries where the % of female graduates is less than 30%
*/
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.revature.map.Task1Mapper;
import com.revature.reduce.Task1Reducer;


public class Task1Driver {

	public static void main(String[] args) throws Exception {
		if(args.length != 2){
			System.out.printf("Provide input data parameter and output folder name parameter");
			System.out.println("\n");
			System.out.println("\n");
			System.exit(-1);
		}
		
		Job job = new Job();
		job.setJarByClass(Task5Mapper.class);
		job.setJobName("Task 5: Find Females That Are Head of Household <30%");
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setMapperClass(Task5Mapper.class);
		job.setReducerClass(Task5Reducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		boolean success = job.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	}
}
