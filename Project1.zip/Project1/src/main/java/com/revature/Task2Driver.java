package com.revature;
/*
 * This MapReduce Driver will call a mapper and reducer in order to return the 
 * average increase in femaile education from the year 2000.
 */
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.revature.map.Task2Mapper;
import com.revature.reduce.Task2Reducer;


public class Task2Driver {

	public static void main(String[] args) throws Exception {
		if(args.length != 2){
			System.out.println("Need input data parameter, and output folder parameter");
			System.out.println("\n");
			System.out.println("\n");
			System.exit(-1);
		}
		
		Job job = new Job();
		
		job.setJarByClass(Task2Mapper.class);
		job.setJobName("Task 2: Avg Increase in US Female Education Since 2000");
		
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		job.setMapperClass(Task2Mapper.class);
		job.setReducerClass(Task2Reducer.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		boolean success = job.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	}
}