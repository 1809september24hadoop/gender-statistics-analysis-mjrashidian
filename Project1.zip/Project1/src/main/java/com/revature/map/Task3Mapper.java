package com.revature.map;

/*
 * This mapper will pull lines from a CSV, splitting the line, and replacing all commas with
 * a different delimiter (the semi-colon), in order to clean the data and prepare further reading
 * from the reducer.
 */

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Task3Mapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	int count = 1;
	
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException{
		String line = value.toString();
		StringBuilder newLine = new StringBuilder();		
		for(String word: line.split("[\\r\\n]+")){
			if(word.length() > 0){
				String[] parts = word.split("\",");
				for(int i=0; i < parts.length; i++){
					parts[i].trim();
					if(i != parts.length){
						newLine.append(parts[i]);
						newLine.append(";");
					}
				}
				String a = newLine.toString();
				String s = a.replaceAll("\"", "");
				context.write(new Text(s), new IntWritable(count++));
			}
		}
	}
}