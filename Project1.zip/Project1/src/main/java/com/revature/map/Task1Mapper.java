package com.revature.map;
/*
 *This Mapper will find the values of a line from a CSV and pull them into context  
 * 
 */
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Task1Mapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	int num = 1;
	
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException{
		
		String line = value.toString();
		StringBuilder newLine = new StringBuilder();
		
		
		for(String word: line.split("[\\r\\n]+")){
			if(word.length() > 0){
				if((word.indexOf("graduation ratio") != -1)
						&&(word.indexOf("tertiary")!=-1)
						&&(word.indexOf("female")!=-1)){
					String[] parts = word.split("\",");
					for(int i=0; i < parts.length; i++){
						parts[i].trim();
						newLine.append(parts[i]);
						if(i != parts.length-1){
							newLine.append(";");
						}
					}
					String a = newLine.toString();
					String s = a.replaceAll("\"", "");
					context.write(new Text(s), new IntWritable(num++));
				}
			}
		}
	}
}
