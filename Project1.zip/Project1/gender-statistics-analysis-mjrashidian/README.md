# Gender Statistic Analysis
+ Requirements specified in the word document
+ Data set available in [S3](https://s3.amazonaws.com/hadoop-dataset/genter-stats-data.zip)